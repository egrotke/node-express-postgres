--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.transfers DROP CONSTRAINT transfers_pkey;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT transactions_pkey;
ALTER TABLE ONLY public.recipients DROP CONSTRAINT recipients_pkey;
ALTER TABLE ONLY public.deposits DROP CONSTRAINT deposits_pkey;
ALTER TABLE ONLY public.bills DROP CONSTRAINT bills_pkey;
ALTER TABLE ONLY public.billers DROP CONSTRAINT billers_pkey;
ALTER TABLE ONLY public.accounttypes DROP CONSTRAINT accounttypes_pkey;
ALTER TABLE ONLY public.accounts DROP CONSTRAINT accounts_pkey;
DROP TABLE public.users;
DROP TABLE public.transfers;
DROP TABLE public.transactions;
DROP TABLE public.recipients;
DROP TABLE public.deposits;
DROP TABLE public.bills;
DROP TABLE public.billers;
DROP TABLE public.accounttypes;
DROP TABLE public.accounts;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: egrotke
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO egrotke;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: egrotke
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE accounts (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    nickname character varying(128) NOT NULL,
    acct_no character varying(32) NOT NULL,
    account_type character varying(128) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_internal boolean NOT NULL,
    balance numeric(64,2) NOT NULL,
    available_balance numeric(64,2) NOT NULL,
    apy numeric(32,2) NOT NULL,
    interest_rate numeric(32,2) NOT NULL,
    swift_code character varying(32) NOT NULL,
    odloc_account smallint NOT NULL,
    ytd_interest numeric(32,2) NOT NULL,
    accrued_interest numeric(32,2) NOT NULL,
    lastyear_interest numeric(32,2) NOT NULL,
    routing_string character varying(256) NOT NULL,
    routing_number integer NOT NULL,
    shortname character varying(64) NOT NULL,
    account_type_long character varying(128) NOT NULL,
    principal_balance numeric(64,2) NOT NULL,
    available_credit numeric(32,2) NOT NULL,
    issue_date timestamp without time zone NOT NULL,
    maturity_date timestamp without time zone NOT NULL,
    as_of timestamp without time zone NOT NULL,
    issue_amount numeric(32,2) NOT NULL,
    renewal_date timestamp without time zone NOT NULL,
    term character varying(32) NOT NULL,
    bills integer[],
    transfers integer[],
    deposits integer[],
    transactions integer[],
    second_user integer
);


ALTER TABLE accounts OWNER TO egrotke;

--
-- Name: accounttypes; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE accounttypes (
    id smallint NOT NULL,
    name character varying(128) NOT NULL,
    token character varying(128) NOT NULL,
    balance_meta character varying(128) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    accounts_from_type integer[]
);


ALTER TABLE accounttypes OWNER TO egrotke;

--
-- Name: billers; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE billers (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    ebill smallint NOT NULL,
    user_id integer NOT NULL,
    lastamount numeric(32,0) NOT NULL,
    lastdate timestamp without time zone NOT NULL
);


ALTER TABLE billers OWNER TO egrotke;

--
-- Name: bills; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE bills (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    number integer NOT NULL,
    amount numeric(10,0) NOT NULL,
    pay_date timestamp without time zone NOT NULL,
    scheduled smallint NOT NULL,
    user_id integer NOT NULL,
    account integer NOT NULL,
    biller integer NOT NULL,
    ebill integer NOT NULL
);


ALTER TABLE bills OWNER TO egrotke;

--
-- Name: deposits; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE deposits (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    amount numeric(10,0) NOT NULL,
    name character varying(128) NOT NULL,
    meta character varying(128) NOT NULL,
    account integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE deposits OWNER TO egrotke;

--
-- Name: recipients; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE recipients (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    phone_no character varying(32) NOT NULL,
    email character varying(64) NOT NULL,
    user_id integer NOT NULL,
    lastdate timestamp without time zone NOT NULL,
    lastamount numeric(10,0) NOT NULL
);


ALTER TABLE recipients OWNER TO egrotke;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE transactions (
    id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    description character varying(256) NOT NULL,
    amount numeric(64,2) NOT NULL,
    balance numeric(64,2) NOT NULL,
    category character varying(64) NOT NULL,
    account_id integer NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    transaction_type character varying(128) NOT NULL,
    name character varying(128) NOT NULL,
    location character varying(128) NOT NULL,
    age integer NOT NULL,
    transaction_age integer NOT NULL,
    hascheck smallint NOT NULL
);


ALTER TABLE transactions OWNER TO egrotke;

--
-- Name: transfers; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE transfers (
    id integer NOT NULL,
    user_id integer NOT NULL,
    account integer NOT NULL,
    recipient character varying(64) NOT NULL,
    location character varying(128) NOT NULL,
    amount numeric(10,0) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    transaction_type character varying(64) NOT NULL,
    favorited smallint NOT NULL,
    scheduled smallint NOT NULL,
    is_personal smallint NOT NULL,
    is_internal smallint NOT NULL,
    recurrence character varying(64)
);


ALTER TABLE transfers OWNER TO egrotke;

--
-- Name: users; Type: TABLE; Schema: public; Owner: egrotke; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    lastname character varying(255) DEFAULT NULL::character varying,
    email character varying(255) DEFAULT NULL::character varying,
    password character varying(255) DEFAULT NULL::character varying,
    firstname character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    accounts integer[],
    accounttypes integer[],
    billers integer[],
    bills integer[],
    transfers integer[],
    deposits integer[],
    recipients integer[],
    username character varying(255)
);


ALTER TABLE users OWNER TO egrotke;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY accounts (id, name, nickname, acct_no, account_type, created_at, updated_at, is_internal, balance, available_balance, apy, interest_rate, swift_code, odloc_account, ytd_interest, accrued_interest, lastyear_interest, routing_string, routing_number, shortname, account_type_long, principal_balance, available_credit, issue_date, maturity_date, as_of, issue_amount, renewal_date, term, bills, transfers, deposits, transactions, second_user) FROM stdin;
\.
COPY accounts (id, name, nickname, acct_no, account_type, created_at, updated_at, is_internal, balance, available_balance, apy, interest_rate, swift_code, odloc_account, ytd_interest, accrued_interest, lastyear_interest, routing_string, routing_number, shortname, account_type_long, principal_balance, available_credit, issue_date, maturity_date, as_of, issue_amount, renewal_date, term, bills, transfers, deposits, transactions, second_user) FROM '$$PATH$$/2319.dat';

--
-- Data for Name: accounttypes; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY accounttypes (id, name, token, balance_meta, user_id, created_at, updated_at, accounts_from_type) FROM stdin;
\.
COPY accounttypes (id, name, token, balance_meta, user_id, created_at, updated_at, accounts_from_type) FROM '$$PATH$$/2311.dat';

--
-- Data for Name: billers; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY billers (id, name, ebill, user_id, lastamount, lastdate) FROM stdin;
\.
COPY billers (id, name, ebill, user_id, lastamount, lastdate) FROM '$$PATH$$/2312.dat';

--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY bills (id, name, number, amount, pay_date, scheduled, user_id, account, biller, ebill) FROM stdin;
\.
COPY bills (id, name, number, amount, pay_date, scheduled, user_id, account, biller, ebill) FROM '$$PATH$$/2313.dat';

--
-- Data for Name: deposits; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY deposits (id, created_at, amount, name, meta, account, user_id) FROM stdin;
\.
COPY deposits (id, created_at, amount, name, meta, account, user_id) FROM '$$PATH$$/2314.dat';

--
-- Data for Name: recipients; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY recipients (id, name, phone_no, email, user_id, lastdate, lastamount) FROM stdin;
\.
COPY recipients (id, name, phone_no, email, user_id, lastdate, lastamount) FROM '$$PATH$$/2315.dat';

--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY transactions (id, created_at, description, amount, balance, category, account_id, updated_at, transaction_type, name, location, age, transaction_age, hascheck) FROM stdin;
\.
COPY transactions (id, created_at, description, amount, balance, category, account_id, updated_at, transaction_type, name, location, age, transaction_age, hascheck) FROM '$$PATH$$/2316.dat';

--
-- Data for Name: transfers; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY transfers (id, user_id, account, recipient, location, amount, created_at, transaction_type, favorited, scheduled, is_personal, is_internal, recurrence) FROM stdin;
\.
COPY transfers (id, user_id, account, recipient, location, amount, created_at, transaction_type, favorited, scheduled, is_personal, is_internal, recurrence) FROM '$$PATH$$/2317.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: egrotke
--

COPY users (id, lastname, email, password, firstname, created_at, updated_at, accounts, accounttypes, billers, bills, transfers, deposits, recipients, username) FROM stdin;
\.
COPY users (id, lastname, email, password, firstname, created_at, updated_at, accounts, accounttypes, billers, bills, transfers, deposits, recipients, username) FROM '$$PATH$$/2318.dat';

--
-- Name: accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accounttypes_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY accounttypes
    ADD CONSTRAINT accounttypes_pkey PRIMARY KEY (id);


--
-- Name: billers_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY billers
    ADD CONSTRAINT billers_pkey PRIMARY KEY (id);


--
-- Name: bills_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (id);


--
-- Name: deposits_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY deposits
    ADD CONSTRAINT deposits_pkey PRIMARY KEY (id);


--
-- Name: recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY recipients
    ADD CONSTRAINT recipients_pkey PRIMARY KEY (id);


--
-- Name: transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: egrotke; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: egrotke
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM egrotke;
GRANT ALL ON SCHEMA public TO egrotke;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

